# config.py

CONCEPT = "Urban Digital Twin"
